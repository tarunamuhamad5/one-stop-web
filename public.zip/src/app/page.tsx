"use client";
import React from "react";
import Landing from "@/components/Landing";

export default function Main() {
    return (
        <div>
            <Landing />;
        </div>
    );
}
