import React from "react";
import { Typography, Box, Container } from "@mui/material";
import ContentCard from "@/components/ContentCard";

export default function Teknis() {
    const DataRoles = [
        {
            title: "Susenas Maret 20241",
            src_image: "/content/sosial/susenas.png",
            link: "/Teknis/susenas",
            websiteType: "internal",
        },
        {
            title: "Susenas Maret 20242",
            src_image: "/content/sosial/susenas.png",
            link: "/Teknis/susenas",
            websiteType: "external",
        },
        {
            title: "Susenas Maret 20243",
            src_image: "/content/sosial/susenas.png",
            link: "https://www.youtube.com/",
            websiteType: "external",
        },
    ];

    const baris2 = [
        {
            title: "ini contoh baris2",
            src_image: "/content/sosial/susenas.png",
            link: "/",
            websiteType: "internal",
        },
    ];

    return (
        <div>
            <Box
                minHeight={"100vh"}
                minWidth={"100%"}
                sx={{
                    alignContent: "center",
                    display: "flex",
                    flexWrap: "wrap",
                }}
            >
                <Container
                    sx={{
                        textAlign: "center",
                        left: 0,
                        top: 0,
                    }}
                >
                    <Typography variant="h1">Teknis Pages</Typography>
                    <ContentCard DataContent={DataRoles} />
                    <Typography variant="h3">Teknis Pages</Typography>
                    <iframe
                        width={800}
                        height={800}
                        src="https://docs.google.com/spreadsheets/d/e/2PACX-1vSpxtYaxipJ-mpMWLvi8ZnRp6HyGdPc8NQdbEqaMwaEeaSTNFbjVW8q2IlOva6KQMuwwoRH5E0JThMo/pubhtml?widget=true&amp;headers=false"
                    ></iframe>

                    <iframe
                        width={800}
                        height={800}
                        src="https://drive.google.com/embeddedfolderview?id=1HidW256VTZ-DqdcunjcRtj85EnteFLdV#list"
                    ></iframe>
                </Container>
            </Box>
        </div>
    );
}
